"""
Django LDAP user authentication backend for Python 3.
"""


__version__ = (0, 11, 3)
